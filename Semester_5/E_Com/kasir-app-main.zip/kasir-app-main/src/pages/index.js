import Home from "./Home";
import Success from "./Success";

export { Home, Success };
