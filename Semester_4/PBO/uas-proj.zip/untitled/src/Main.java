// name :
// nim :
// you do not have authority to change this file !!

class Main {
    public static void main(String[] args) {

        // input :
        Student stu = new Student("Lockey", "Irawan", 23, 1, 1988, Major.IT);

        // output :
        // LoIr23011988:Lockey Irawan:23/01/1988:Information Technology
        System.out.println(stu);

    }
}