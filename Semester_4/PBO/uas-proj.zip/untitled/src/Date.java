// nim :
// date :

public class Date {
    private int day;
    private int month;
    private int year;

    // getter and setter as needed
    // day = 1 .. 28,29,30,31 according to month and year
    // month = 1 .. 12
    // year = 1900 - 2023
    // score = 20
    public void set(int d, int m, int y) {}

    // return format = dd/mm/yyyy
    public String toString() {
        return new String();
    }

}
