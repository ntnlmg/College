// date :
// name :

public enum Major {
    IS(""),
    IT(""),
    Design("");

    // modified constructor
    // score = 20
    Major(String i) {
        // IS for Information System
        // IT for Information technology
        // Design for Visual and Communication Design
    }

    // getter

}
