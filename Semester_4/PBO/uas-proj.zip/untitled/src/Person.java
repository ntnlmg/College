// name :
// date :
// you do not have authority to change this file !!

public abstract class Person {
    private String fname;
    private String lname;

    public String toString() {
        return fname + " " + lname;
    }
}
