# KasirKu

KasirKu is a cashier app that is used through your Android phone / tablet and can print receipts via Bluetooth
<br/>
Aplikasi Kasir / POS untuk handphone android / table dengan print bluetooth
<br/>


<img src="img1.png" width="400" alt="KasirKu"></img>
<img src="img2.png" width="400" alt="KasirKu"></img>

<br/>

<img src="img3.png" width="400" alt="KasirKu"></img>
<img src="img4.png" width="400" alt="KasirKu"></img>
<br/>
<img src="img5.png" width="400" alt="KasirKu"></img>
<img src="img6.jpg" width="400" alt="KasirKu"></img>

####  Features
- Login page
- Master data management
- Simple Order page
- Print Receitps via Bluetooth
- Report (unfinished)
- Setting (unfinished)
